namespace TodoList.WebApi.Configurations
{
    public class ApplicationCorsOptions
    {
        public string PolicyName { get; set; }
        public string AllowedOrigin { get; set; }
    }
}
