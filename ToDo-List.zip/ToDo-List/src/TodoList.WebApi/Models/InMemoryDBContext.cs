﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace TodoList.WebApi.Models
{
    public class InMemoryDBContext : DbContext
    {
        public InMemoryDBContext(DbContextOptions<InMemoryDBContext> options)
            : base(options)
        {
        }

        public DbSet<TodoItem> ToDoTable { get; set; }
    }
}
