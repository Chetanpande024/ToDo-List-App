using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using Microsoft.EntityFrameworkCore;
using TodoList.WebApi.Models;

namespace TodoList.WebApi.Repositories
{
    public class TodoItemRepository : ITodoItemRepository
    {
        private readonly InMemoryDBContext _context;

        public TodoItemRepository(InMemoryDBContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<TodoItem>> GetTodoItems()
        {
            return await _context.ToDoTable.ToListAsync();
        }

        public async Task<TodoItem> GetTodoById(int id)
        {
            return await _context.ToDoTable.FindAsync(id);
        }

        public async Task Insert(TodoItem todoItem)
        {
            _context.ToDoTable.Add(todoItem);
            await _context.SaveChangesAsync();
        }

        public async Task Update(int id, TodoItem todoItem)
        {
            _context.Entry(todoItem).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
        public async Task Delete(int id)
        {
            var toDoModel = await _context.ToDoTable.FindAsync(id);
            _context.ToDoTable.Remove(toDoModel);
            await _context.SaveChangesAsync();
        }
    }
}
