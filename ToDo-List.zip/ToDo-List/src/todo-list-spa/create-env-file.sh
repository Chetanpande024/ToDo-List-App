echo "REACT_APP_API_URL=$1" > /app/.env
