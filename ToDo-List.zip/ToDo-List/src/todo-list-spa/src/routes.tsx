import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import { TodoList } from './pages';

export const Routes: React.FC = () => {
    return (
        <BrowserRouter>
            <Route path="/" exact component={TodoList} />
        </BrowserRouter>
    );
};
