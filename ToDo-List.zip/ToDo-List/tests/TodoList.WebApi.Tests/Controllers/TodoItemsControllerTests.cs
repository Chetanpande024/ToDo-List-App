using System;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using TodoList.WebApi.Controllers;
using TodoList.WebApi.Models;
using TodoList.WebApi.Repositories;
using Xunit;

namespace TodoList.WebApi.Tests.Controllers
{
    public class TodoItemsControllerTests
    {
        [Fact]
        public async Task Create_ValidTodoItem_ReturnsTodoItemWithId()
        {
            int expectedId = 1;
            var model = GetValidTodoItem();

            var fakeTodoRepository = new Mock<ITodoItemRepository>();
            fakeTodoRepository
                .Setup(repository => repository.Insert(It.IsAny<TodoItem>()))
                .Callback<TodoItem>(todo => todo.Id = expectedId)
                .Returns(Task.CompletedTask);

            var todoItemsController = new TodoItemsController(fakeTodoRepository.Object);

            ActionResult<TodoItem> result = await todoItemsController.Create(model);

            result
                .Result
                .As<CreatedAtActionResult>()
                .Value
                .As<TodoItem>()
                .Id
                .Should()
                .Be(expectedId);
        }

        [Fact]
        public async Task Create_ValidTodoItem_ReturnsCreatedResult()
        {
            var model = GetValidTodoItem();
            var fakeTodoRepository = new Mock<ITodoItemRepository>();
            fakeTodoRepository
                .Setup(repository => repository.Insert(It.IsAny<TodoItem>()))
                .Returns(Task.CompletedTask);

            var todoItemsController = new TodoItemsController(fakeTodoRepository.Object);

            ActionResult<TodoItem> result = await todoItemsController.Create(model);

            result.Result.Should().BeOfType<CreatedAtActionResult>();
        }

        [Fact]
        public async Task Update_ExistingTodoItem_ReturnsNoContent()
        {
            int id = 1;
            var model = GetValidTodoItem();
            var todoItemStoredInDatabase = GetValidTodoItemWithId(Id: 1);
            var fakeTodoRepository = new Mock<ITodoItemRepository>();
            fakeTodoRepository
                .Setup(repository => repository.GetTodoById(It.IsAny<int>()))
                .Returns(Task.FromResult(todoItemStoredInDatabase));

            var todoItemsController = new TodoItemsController(fakeTodoRepository.Object);

            ActionResult result = await todoItemsController.Update(id, model);

            result.Should().BeOfType<NoContentResult>();
        }

        [Fact]
        public async Task Delete_NonexistentId_ReturnsNotFound()
        {
            int id = 1;
            var fakeTodoRepository = new Mock<ITodoItemRepository>();
            fakeTodoRepository
                .Setup(repository => repository.GetTodoById(It.IsAny<int>()))
                .Returns(Task.FromResult<TodoItem>(null));

            var todoItemsController = new TodoItemsController(fakeTodoRepository.Object);

            ActionResult result = await todoItemsController.Delete(id);

            result.Should().BeOfType<NotFoundResult>();
        }

        [Fact]
        public async Task Delete_ExistingTodoItem_ReturnsNoContent()
        {
            int id = 1;
            var todoItemStoredInDatabase = GetValidTodoItemWithId(Id: 1);
            var fakeTodoRepository = new Mock<ITodoItemRepository>();
            fakeTodoRepository
                .Setup(repository => repository.GetTodoById(It.IsAny<int>()))
                .Returns(Task.FromResult(todoItemStoredInDatabase));

            var todoItemsController = new TodoItemsController(fakeTodoRepository.Object);

            ActionResult result = await todoItemsController.Delete(id);

            result.Should().BeOfType<NoContentResult>();
        }

        [Fact]
        public async Task Show_NonexistentId_ReturnsNotFound()
        {
            int id = 1;
            var fakeTodoRepository = new Mock<ITodoItemRepository>();
            fakeTodoRepository
                .Setup(repository => repository.GetTodoById(It.IsAny<int>()))
                .Returns(Task.FromResult<TodoItem>(null));

            var todoItemsController = new TodoItemsController(fakeTodoRepository.Object);

            ActionResult<TodoItem> result = await todoItemsController.Show(id);

            result.Result.Should().BeOfType<NotFoundResult>();
        }

        [Fact]
        public async Task Show_ExistingTodoItem_ReturnsNoContent()
        {
            int id = 1;
            var todoItemStoredInDatabase = GetValidTodoItemWithId(Id: 1);
            var fakeTodoRepository = new Mock<ITodoItemRepository>();
            fakeTodoRepository
                .Setup(repository => repository.GetTodoById(It.IsAny<int>()))
                .Returns(Task.FromResult(todoItemStoredInDatabase));

            var todoItemsController = new TodoItemsController(fakeTodoRepository.Object);

            ActionResult<TodoItem> result = await todoItemsController.Show(id);

            result
                .Result
                .As<OkObjectResult>()
                .Value
                .As<TodoItem>()
                .Should()
                .BeSameAs(todoItemStoredInDatabase);
        }

        private TodoItem GetValidTodoItemWithId(int Id)
        {
            return new TodoItem
            {
                Id = 1,
                Title = "Todo Task",
                Completed = false
            };
        }

        private TodoItem GetValidTodoItem()
        {
            return new TodoItem
            {
                Title = "Todo Task",
                Completed = false
            };
        }
    }
}
